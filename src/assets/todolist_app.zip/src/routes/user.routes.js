const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/auth');
const userController = require('../controllers/user.controller');


// GET /user
router.get('/profile', authMiddleware, userController.getProfile);

module.exports = router;