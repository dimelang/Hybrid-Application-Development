const express = require('express');
const router = express.Router();
const taskController = require('../controllers/task.controller');
const TaskValidator = require('../validators/task.validation');
const validate = require('../middlewares/validation');
const authMiddleware = require('../middlewares/auth');

router.get('/', authMiddleware, taskController.getUserTasks);
router.get('/:id', TaskValidator.idParam(), validate, authMiddleware, taskController.getTaskById);
router.post('/', TaskValidator.createTask(), validate, authMiddleware, taskController.createTask);
router.patch('/:id', TaskValidator.updateTask(), validate, authMiddleware, taskController.updateTask);
router.delete('/:id', TaskValidator.idParam(), validate, authMiddleware, taskController.deleteTask);


module.exports = router;