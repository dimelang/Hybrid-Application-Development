const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const authValidation = require('../validators/auth.validation');
const validate = require('../middlewares/validation');
const authMiddleware = require('../middlewares/auth');

router.post('/register', authValidation.registerValidation(), validate, authController.register);
router.post('/login', authValidation.loginValidation(), validate, authController.login);
router.patch('/reset-password', authValidation.forgotPassword(), validate, authMiddleware, authController.resetPassword);


module.exports = router; 
