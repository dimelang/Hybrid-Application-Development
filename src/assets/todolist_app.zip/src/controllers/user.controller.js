const userService = require('../services/user.service');

class UserController {
    async getUsers(req, res) {
        try {
            const users = await userService.getUsers();
            res.status(200).json({
                success: true,
                data: users
            });
        } catch (error) {
            res.status(404).json({
                success: false,
                message: error.message
            });
        }
    }

    async getUserById(req, res) {
        try {
            const { id } = req.params;
            const user = await userService.findById(id);
            res.status(200).json({
                success: true,
                data: user
            })
        } catch (error) {
            res.status(404).json({
                success: false,
                message: error.message
            });
        }
    }

    async getProfile(req, res) {
        res.status(200).json({
            success: true,
            data: req.user
        })
    }
}

module.exports = new UserController();