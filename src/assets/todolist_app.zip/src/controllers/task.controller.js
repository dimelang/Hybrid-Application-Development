const taskService = require('../services/task.service');

class TaskController {
    async getTaskById(req, res) {
        try {
            const { id } = req.params;
            const userId = req.user.id;
            const task = await taskService.getTaskById(id, userId);

            res.status(200).json({
                success: true,
                data: task
            })
        } catch (error) {
            res.status(404).json({
                success: false,
                message: error.message
            })
        }
    }

    async getUserTasks(req, res) {
        try {
            const userId = req.user.id;
            const result = await taskService.getUserTasks(userId);

            res.status(200).json({
                success: true,
                data: result
            });
        } catch (error) {
            res.status(404).json({
                success: false,
                message: error.message
            })
        }
    }

    async createTask(req, res) {
        try {
            const taskData = req.body;
            const userId = req.user.id;
            console.log(req.user);

            const result = await taskService.createTask(taskData, userId);

            res.status(201).json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async updateTask(req, res) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            const userId = req.user.id;
            const result = await taskService.updateTask(id, updateData, userId);
            res.status(200).json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async deleteTask(req, res) {
        try {
            const { id } = req.params;
            const userId = req.user.id;
            const result = await taskService.deleteTask(id, userId);
            res.status(200).json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            })
        }
    }
}

module.exports = new TaskController();