const db = require('../configs/db');

class TaskRepository {
    async findById(id, user_id) {
        const query = 'SELECT * FROM tb_tasks WHERE id=? AND user_id=?';
        const [result] = await db.execute(query, [id, user_id]);
        return result[0] || null;
    }

    async findByUserId(user_id) {
        const query = 'SELECT * FROM tb_tasks WHERE user_id=?';
        const [result] = await db.execute(query, [user_id]);
        return result;
    }

    async createTask(taskData) {
        const keys = Object.keys(taskData);
        const values = Object.values(taskData);

        const query = `INSERT INTO tb_tasks (${keys.join(", ")}) VALUES (${keys.map(_ => '?').join(', ')})`;

        const [result] = await db.execute(query, values);
        return result.affectedRows > 0;
    }

    async updateTask(id, taskData) {
        const keys = Object.keys(taskData);
        const values = Object.values(taskData);

        const query = `UPDATE tb_tasks SET ${keys.map(key => key + "=?").join(", ")} WHERE id=?`;
        const [result] = await db.execute(query, [...values, id]);
        return result.affectedRows > 0;
    }

    async deleteTask(id) {
        const query = `DELETE FROM tb_tasks WHERE id=?`;
        const [result] = await db.execute(query, [id]);
        return result.affectedRows > 0;
    }
}

module.exports = new TaskRepository();