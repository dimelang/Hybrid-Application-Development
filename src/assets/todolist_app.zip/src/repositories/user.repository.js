const db = require('../configs/db');

class UserRepository {
    async getUsers() {
        const query = "SELECT * FROM tb_users";
        const [result] = await db.execute(query);
        return result;
    }

    async findById(id) {
        const query = "SELECT id, email, username, role FROM tb_users WHERE id=?";
        const [result] = await db.execute(query, [id]);
        return result[0] || null;
    }

    async findByEmail(email) {
        const query = "SELECT * FROM tb_users WHERE email=?";
        const [result] = await db.execute(query, [email]);
        return result[0] || null;
    }

    async createUser(userData) {
        const keys = Object.keys(userData);
        const values = Object.values(userData);

        const query = `INSERT INTO tb_users (${keys.join(', ')}) VALUES(${keys.map(_ => "?").join(', ')})`;
        const [result] = await db.execute(query, values);
        return result.affectedRows > 0;
    }

    async updateUser(id, userData) {
        const keys = Object.keys(userData);
        const values = Object.values(userData);

        const query = `UPDATE tb_users SET ${keys.map(key => key + '=?').join(', ')} WHERE id=?`;
        const [result] = await db.execute(query, [...values, id]);
        return result.affectedRows > 0;
    }

}

module.exports = new UserRepository();