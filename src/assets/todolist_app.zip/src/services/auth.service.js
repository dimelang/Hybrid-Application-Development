const userRepository = require('../repositories/user.repository');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

class AuthService {
    async register(userData) {
        const { email, username, password } = userData;

        const emailIsUsed = await userRepository.findByEmail(email);
        if (emailIsUsed) throw new Error("Email sudah terdaftar");

        const hashedPassword = await bcrypt.hash(password, 10);
        const registerUser = await userRepository.createUser({
            email,
            username,
            password: hashedPassword,
            role: "GUEST"
        });

        if (!registerUser) throw new Error("Gagal melakukan registrasi user");
        return {
            success: true,
            message: "Berhasil melakukan registrasi"
        }
    }

    async login(email, password) {
        const user = await userRepository.findByEmail(email);
        if (!user) throw new Error("Email atau password salah");

        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) throw new Error("Email atau password salah");

        const payload = {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role
        };

        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

        return {
            success: true,
            token
        }
    }

    async resetPassword(userId, userData) {
        const { email, password, confirm_password } = userData;
        const hashedPassword = await bcrypt.hash(userData.password, 10);
        const user = await userRepository.updateUser(userId, {
            password: hashedPassword,
        });

        if (!user) throw new Error("Gagal reset password");
        return {
            success: true,
            message: "Berhasil reset password"
        }

    }

    async verifyToken(token) {
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await userRepository.findById(decoded.id);

            if (!user) throw new Error('User tidak ditemukan');

            return user;
        } catch (error) {
            throw new Error("Token tidak valid");
        }
    }
}

module.exports = new AuthService();