const taskRepository = require('../repositories/task.repository');

class TaskService {
    async getTaskById(id, user_id) {
        const task = await taskRepository.findById(id, user_id);
        if (!task) throw new Error("Task tidak ditemukan");
        return task;
    }

    async getUserTasks(userId) {
        const tasks = await taskRepository.findByUserId(userId);
        if (!tasks) throw new Error("Task dari user ini tidak ditemukan");
        return tasks;
    }

    async createTask(taskData, userId) {
        const createdTask = await taskRepository.createTask({
            ...taskData,
            status: false,
            user_id: userId
        });
        if (!createdTask) throw new Error("Gagal menambahkan task");
        return {
            success: true,
            message: "Berhasil menambahkan task baru"
        }
    }

    async updateTask(id, updatedData, userId) {
        const existingData = await taskRepository.findById(id, userId);
        if (!existingData) throw new Error("Task tidak ditemukan");

        const result = await taskRepository.updateTask(id, updatedData);
        return {
            success: true,
            message: result ? "Berhasil memperbarui data task" : "Tidak ada task yang diperbarui"
        };
    }

    async deleteTask(id, userId) {
        const existingData = await taskRepository.findById(id, userId);
        if (!existingData) throw new Error("Task tidak ditemukan");

        const result = await taskRepository.deleteTask(id);

        return {
            success: true,
            message: result ? "Berhasil menghapus data task" : "Tidak ada task yang dihapus"
        }
    }
}

module.exports = new TaskService();