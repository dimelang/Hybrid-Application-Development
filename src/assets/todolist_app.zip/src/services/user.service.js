const userRepository = require("../repositories/user.repository");

class UserService {
    async getUsers() {
        const users = await userRepository.getUsers();
        if (!users) throw new Error("Gagal mendapatkan data seluruh user");
        return users;
    }

    async findById(id) {
        const user = await userRepository.findById(id);
        if (!user) throw new Error("User tidak ditemukan");
        return user;
    }

    async findByEmail(email) {
        const user = await userRepository.findByEmail(email);
        if (!user) throw new Error("User tidak ditemukan");
        return user;
    }
}

module.exports = new UserService();