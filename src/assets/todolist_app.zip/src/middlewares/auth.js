const authService = require('../services/auth.service');

module.exports = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader) {
            return res.status(401).json({
                success: false,
                message: 'Token tidak ditemukan'
            });
        }

        const [type, token] = authHeader.split(' ');
        if (type !== 'Bearer' || !token) {
            return res.status(401).json({
                success: false,
                message: 'Format token tidak valid'
            });
        }

        const user = await authService.verifyToken(token);
        req.user = user;
        next();
    } catch (error) {
        next(error);
    }
}