const { body } = require('express-validator');

class AuthValidator {
    static registerValidation() {
        return [
            body('email')
                .trim()
                .notEmpty().withMessage('Email wajib diisi')
                .isEmail().withMessage("Format email tidak valid")
                .normalizeEmail(),

            body('username')
                .trim()
                .notEmpty().withMessage("Username wajib diisi"),

            body('password')
                .notEmpty().withMessage("Password wajib diisi")
                .isLength({ min: 6 }).withMessage('Minimal 6 karakter'),
        ];
    }

    static loginValidation() {
        return [
            body('email')
                .trim()
                .notEmpty().withMessage('Email wajib diisi')
                .isEmail().withMessage("Format email tidak valid")
                .normalizeEmail(),

            body('password')
                .notEmpty().withMessage("Password wajib diisi")
        ];
    }

    static forgotPassword() {
        return [
            body('email')
                .trim()
                .notEmpty().withMessage('Email wajib diisi')
                .isEmail().withMessage("Format email tidak valid")
                .normalizeEmail(),

            body('password')
                .notEmpty().withMessage("Password wajib diisi")
                .isLength({ min: 6 }).withMessage('Minimal 6 karakter'),

            body('confirm_password')
                .notEmpty().withMessage('Konfirmasi password wajib diisi')
                .custom(async (value, { req }) => {
                    if (value !== req.body.password) throw new Error("Konfirmasi password tidak cocok")
                })
        ];
    }
}

module.exports = AuthValidator;
