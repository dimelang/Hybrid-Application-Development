const { body, param } = require('express-validator');
const userService = require('../services/user.service');

class TaskValidator {
    static idParam() {
        return [
            param('id')
                .isInt().withMessage('ID task harus berupa angka')
        ];
    }

    static createTask() {
        return [
            body('description')
                .optional()
                .isString().withMessage("Deskripsi harus berupa string"),

            body('priority')
                .optional()
                .isIn(['LOW', 'MEDIUM', 'HIGH']).withMessage("Prioritas tidak valid"),

            body('title')
                .notEmpty().withMessage("Title wajib diisi"),
        ];
    }

    static updateTask() {
        return [
            param('id')
                .isInt().withMessage('ID task harus berupa angka'),

            body('description')
                .optional()
                .isString().withMessage("Deskripsi harus berupa string"),

            body('priority')
                .optional()
                .isIn(['LOW', 'MEDIUM', 'HIGH']).withMessage("Prioritas tidak valid"),

            body('status')
                .optional()
                .isBoolean().withMessage('Status tidak valid'),

            body('title')
                .optional()
                .notEmpty().withMessage("Title wajib diisi"),

        ];
    }
}

module.exports = TaskValidator;